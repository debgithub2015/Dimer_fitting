import sys

Num = int(sys.argv[1])

for i in range(7):
  file = open('submit%i'%i,'w')
  file.write('''#!/bin/bash
#SBATCH -A C3SE001-12-16
#SBATCH -N 4
#SBATCH --job-name=main%i_%i
#SBATCH --exclusive
#SBATCH --time=10:00:00
python calc_main.py %i %i %i'''%(Num,i,Num, i*5,(i+1)*5) )
  file.close()


file = open('submit_ref','w')
file.write('''#!/bin/bash
#SBATCH -A C3SE001-12-16
#SBATCH -N 2
#SBATCH --job-name=ref%i
#SBATCH --exclusive
#SBATCH --time=05:00:00
python calc_ref.py %i '''%(Num,Num))
file.close()


