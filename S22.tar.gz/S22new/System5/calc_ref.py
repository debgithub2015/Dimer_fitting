import os
import sys


NUM = int(sys.argv[1])

i = 0
in_filename = 'S22_%02d_%02d_RefA.in'%(NUM,i)
res_filename = in_filename.split('.')[0]+'.txt'
os.popen('mpiexec mypw.x < %s > %s' %(in_filename,res_filename))


in_filename = 'S22_%02d_%02d_RefB.in'%(NUM,i)
res_filename = in_filename.split('.')[0]+'.txt'
print res_filename
os.popen('mpiexec mypw.x < %s > %s' %(in_filename,res_filename))

