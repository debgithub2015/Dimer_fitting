for i in {0..6}
do
  sbatch submit$i
  sleep 1.0
done

sbatch submit_ref

