
for i in {2..8}
do
  cd System$i/
  bash prepare.sh $i
  cd ..
done


